//import java.util.*;
//public class FinalTest {
//public class Node {
//
//	public State state;
//	public Node parent;
//	public Operator operator;
//	public int depth, pathCost;
//
//	/**
//	 * Constructs a new node with the given state.
//	 * @param state the state encapsulated in the constructed node.
//	 * @param parent the parent from which this node is reached.
//	 * @param operator the operator applied to reach this node.
//	 */
//	public Node(State state, Node parent, Operator operator) {
//		this.state = state;
//		this.parent = parent;
//		this.operator = operator;
//		if (parent != null) {
//			this.depth = parent.getDepth() + 1;
//			this.pathCost = parent.getPathCost() + operator.getCost();
//		}
//
//	}
//
//	/**
//	 * @return the state encapsulated in the node.
//	 */
//	public State getState() {
//		return this.state;
//	}
//
//	/**
//	 * @return the parent node from which this node was reached.
//	 */
//	public Node getParent() {
//		return parent;
//	}
//
//	/**
//	 * @return the operator used to reach this node.
//	 */
//	public Operator getOperator() {
//		return operator;
//	}
//
//	/**
//	 * @return the depth of the node which is the number of operators
//	 * applied from the initial node to reach the current node.
//	 */
//	public int getDepth() {
//		return depth;
//	}
//
//	/**
//	 * @return the path cost of the node.
//	 */
//	public int getPathCost() {
//		return pathCost;
//	}
//
//	/**
//	 * Sets the cost of the current node. Usually used when the path cost
//	 * of the node is not only dependent on the path cost of the previous
//	 * node and the fixed operator cost, but also on how the effect of
//	 * the operator which is a combination of the previous state and the
//	 * operator applied
//	 * @param newCost the new cost of the node.
//	 */
//	public void setPathCost(int newCost) {
//		pathCost = newCost;
//	}
//}
//public abstract class Operator {
//
//
//	public String name;
//	public int cost;
//
//
//	public Operator(String name, int cost) {
//		this.name = name;
//		this.cost = cost;
//	}
//
//	/**
//	 * Applies the operator to the input node.
//	 * @param node the node to which the operator is applied.
//	 * @return the new node after applying the operator.
//	 */
//	public abstract Node apply(Node node);
//
//	/**
//	 * @return the operator cost.
//	 */
//	public int getCost() {
//		return cost;
//	}
//
//	/**
//	 * @return the operator name.
//	 */
//	public String getName() {
//		return name;
//	}
//}
//public abstract class Problem {
//
//	public ArrayList < Operator > operators;
//
//	/**
//	 * @return the operators of the problem.
//	 */
//	public abstract ArrayList < Operator > getOperators();
//
//	/**
//	 * @return the initial state of the problem.
//	 */
//	public abstract State getInitialState();
//
//	/**
//	 * Tests whether the input state is a goal state.
//	 * @param state the state to be tested.
//	 * @return true if the input state is a goal state.
//	 */
//	public abstract boolean testGoal(State state);
//}
//public abstract class State{
//
//	public abstract String toString();
//}
//public class GeneralSearch {
//
//	/**
//	 * Expands the input node using the list of given operators.
//	 * @param node the node to expand using the operators.
//	 * @param operators the operators used to expand the node.
//	 * @return the expanded nodes.
//	 */
//	private ArrayList < Node > expand(Node node, ArrayList < Operator > operators) {
//		ArrayList < Node > expandedNodes = new ArrayList < Node > (1);
//		for (Operator operator: operators) {
//			Node nxtNode = operator.apply(node);
//			if (nxtNode != null)
//				expandedNodes.add(nxtNode);
//		}
//		return expandedNodes;
//	}
//
//	/**
//	 * Searches for a solution to the input problem given a queue controller.
//	 * @param problem the problem to be solved.
//	 * @param queueController the queuing function used for node selection.
//	 * @param visualize a boolean to print the solution with some stats.
//	 */
//	public void search(Problem problem, QueueController queueController, boolean visualize) {
//
//		State initState = problem.getInitialState();
//
//		queueController.makeQueue(new Node(initState, null, null));
//		int expandedNodes = 0;
//		while (!queueController.isEmpty()) {
//			Node node = queueController.removeFront();
//			expandedNodes++;
//			if (problem.testGoal(node.getState())) {
//				System.out.println("Goal Reached!");
//				if (visualize) {
//					printSolution(node);
//					System.out.printf("Solution path length = %d\n", node.getDepth());
//					System.out.printf("Solution path cost = %d\n", node.getPathCost());
//					System.out.printf("# Expanded nodes = %d\n", expandedNodes);
//				}
//				return;
//			}
//
//			queueController.add(expand(node, problem.getOperators()));
//		}
//		System.out.println("Failure :(");
//	}
//
//	/**
//	 * Prints the states of the ancestors of the input node in addition to
//	 * the state of the input node.
//	 * @param node the node to print its state and its ancestors states.
//	 */
//	private void printSolution(Node node) {
//		if (node.getParent() != null) {
//			printSolution(node.getParent());
//			System.out.println(node.getOperator().getName());
//		}
//
//		System.out.println(node.getState());
//	}
//}
//public abstract class QueueController {
//
//	protected TreeMap<State, Integer> vis;
//	protected Node initNode;
//
//	/**
//	 * Checks whether the queue is empty.
//	 * @return true if the queue is empty.
//	 */
//	public abstract boolean isEmpty();
//
//	/**
//	 * Adds the input expanded nodes to the queue (if they are not visited before).
//	 * @param nodes the nodes to be added to the queue.
//	 */
//	public abstract void add(ArrayList<Node> nodes);
//
//	/**
//	 * Constructs a new queue with the initial node.
//	 * @param node the initial node.
//	 */
//	public final void makeQueue(Node node) {
//		initNode = node;
//		vis = new TreeMap<>();
//		ArrayList<Node> nodes = new ArrayList<Node>();
//		nodes.add(initNode);
//		add(nodes);
//	}
//
//	/**
//	 * Removes the front of the queue which is the node chosen for relaxation.
//	 * @return the removed node.
//	 */
//	public abstract Node removeFront();
//}
//public class BreadthFirstSearch extends QueueController {
//
//	private Queue<Node> queue = new LinkedList<>();
//
//	/**
//	 * Checks whether the queue is empty.
//	 * @return true if the queue is empty.
//	 */
//	@Override
//	public boolean isEmpty() { return queue.isEmpty(); }
//
//	/**
//	 * Adds the input expanded nodes to the queue (if they are not visited before).
//	 * @param nodes the nodes to be added to the queue.
//	 */
//	@Override
//	public void add(ArrayList<Node> nodes) {
//		for(Node node: nodes)
//		{
//			Integer pathCost = vis.get(node.getState());
//			if(pathCost == null) {
//				vis.put(node.getState(), node.getPathCost());
//				queue.add(node);
//			}
//		}
//	}
//
//	/**
//	 * Removes the front of the queue which is the node chosen for relaxation.
//	 * The front of the queue in DepthFirstSearch is the first inserted node (FIFO).
//	 * @return the removed node.
//	 */
//	@Override
//	public Node removeFront() { return queue.remove(); }
//
//	
//}
//public class DepthFirstSearch extends QueueController {
//
//	private Stack<Node> stack = new Stack<>();
//
//	/**
//	 * Checks whether the queue is empty.
//	 * @return true if the queue is empty.
//	 */
//	@Override
//	public boolean isEmpty() { return stack.isEmpty(); }
//
//	/**
//	 * Adds the input expanded nodes to the queue (if they are not visited before).
//	 * @param nodes the nodes to be added to the queue.
//	 */
//	@Override
//	public void add(ArrayList<Node> nodes) {
//		for(Node node: nodes)
//		{
//			Integer pathCost = vis.get(node.getState());
//			if(pathCost == null) {
//				vis.put(node.getState(), node.getPathCost());
//				stack.push(node);
//			}
//		}
//	}
//
//	/**
//	 * Removes the front of the queue which is the node chosen for relaxation.
//	 * The front of the queue in DepthFirstSearch is the last inserted node (LIFO).
//	 * @return the removed node.
//	 */
//	@Override
//	public Node removeFront() { return stack.pop(); }
//}
//public class Cell {
//    public String type;
//    public ArrayList <String> visited = new ArrayList <String> ();
//    
//    public Cell(String type) {
//        this.type = type;
//    }
//    public Cell(String type, ArrayList <String> visited) {
//        this.type = type;
//        this.visited = visited;
//    }
//}
//public class westerosOperators extends Operator {
//
//    int killingWhiteWalker = 5;
//    int changeInX;
//    int changeInY;
//
//    public westerosOperators(int changeInX, int changeInY, String name, int cost) {
//        super(name,cost);
//        this.changeInX = changeInX;
//        this.changeInY = changeInY;
//    }
//
//    @Override
//    public Node apply(Node node) {
//
//        westerosState state = (westerosState) node.state;
//        Cell[][] grid = state.grid;
//        boolean killedWW = false;
//        int originalX = state.x;
//        int originalY = state.y;
//        int newX = originalX + changeInX;
//        int newY = originalY + changeInY;
//        int dragonGlass = state.dragonGlassCount;
//		ArrayList <String> neighbours = null;
//        // 1. can't go outside the grid
//        if (!WithinBoundaries(newX, newY))
//            return null;
//
//
//        String cellType = grid[newX][newY].type;
//
//        // 3. can't go into an obstacle
//        if (cellType == "Obstacle")
//            return null;
//
//        if (state.task == "Refill") {
//            if (cellType == "DragonStone") {
//                dragonGlass = 3 ;
//                State newState = new westerosState(newX, newY, grid, dragonGlass);
//                Node newNode = new Node(newState, node, this);
//                return newNode;
//            }
//        }
//
//        if (dragonGlass > 0) {
//            if (state.whiteWalkersNeighbours()) {
//				neighbours = state.whiteWalkersNeighboursPositions();
//                dragonGlass--;
//                killedWW = true;
//            }
//
//        }
//
//        int n = grid.length;
//        int m = grid[0].length;
//        Cell[][] newGrid = new Cell[n][m];
//        for (int i = 0; i < n; i++)
//            for (int j = 0; j < m; j++) {
//                newGrid[i][j] = new Cell(state.grid[i][j].type);
//            }
//        if (neighbours != null) {
//            if (neighbours.contains("North")) {
//                newGrid[originalX - 1][originalY].type = "Free";
//                System.out.println("Kill North");
//            }
//            if (neighbours.contains("South")) {
//                newGrid[originalX + 1][originalY].type = "Free";
//                System.out.println("Kill South");
//            }
//            if (neighbours.contains("West")) {
//                newGrid[originalX][originalY - 1].type = "Free";
//                System.out.println("Kill West");
//            }
//            if (neighbours.contains("East")) {
//                newGrid[originalX][originalY + 1].type = "Free";
//                System.out.println("Kill East");
//            }
//        }
//        // VALID MOVE !!
//        // 1. Construct new state
//
//        State newState = new westerosState(newX, newY, newGrid, dragonGlass);
//        Node newNode = new Node(newState, node, this);
//        if (killedWW)
//            newNode.setPathCost(newNode.getPathCost() + killingWhiteWalker);
//        return newNode;
//    }
//
//    public boolean WithinBoundaries(int x, int y) {
//        if (x <= 3 && y <= 3 && x >= 0 && y >= 0) {
//            return true;
//        }
//        return false;
//    }
//
//}
//public class westerosState extends State {
//    int x;
//    int y;
//    public Cell[][] grid;
//    public int whiteWalkersCount;
//    public int dragonGlassCount;
//    public String task; 
//
//    public westerosState(int x, int y, Cell[][] grid,int dragonGlassCount) {
//        this.x = x;
//        this.y = y;
//        this.grid = grid;
//        this.dragonGlassCount = dragonGlassCount;
//        for (Cell[] row: grid)
//            for (Cell element: row)
//                if (element.type == "WhiteWalker")
//                    this.whiteWalkersCount++;
//        if(this.dragonGlassCount<=0)
//            this.task = "Refill";
//        else
//            this.task="Kill";
//    }
//
//    /**
//     * @return the grid of the current state.
//     */
//    public Cell[][] getGrid() {
//        return grid;
//    }
//    public int whiteWalkersCount() {
//        return whiteWalkersCount;
//    }
//
//
//    public int dragonGlassCount() {
//        return dragonGlassCount;
//    }
//
//
//    public Cell North() {
//
//        return this.grid[this.x - 1][this.y];
//    }
//
//    public Cell South() {
//
//        return this.grid[this.x + 1][this.y];
//    }
//
//    public Cell West() {
//
//        return this.grid[this.x][this.y - 1];
//    }
//
//    public Cell East() {
//
//        return this.grid[this.x][this.y + 1];
//    }
//
//    public ArrayList < String > whiteWalkersNeighboursPositions() {
//        ArrayList < String > positions = new ArrayList < > ();
//        if (this.WithinBoundaries(this.x - 1, this.y)) {
//            if (this.North().type == "WhiteWalker")
//                positions.add("North");
//        }
//        if (this.WithinBoundaries(this.x + 1, this.y)) {
//            if (this.South().type == "WhiteWalker")
//                positions.add("South");
//        }
//        if (this.WithinBoundaries(this.x, this.y - 1)) {
//            if (this.West().type == "WhiteWalker")
//                positions.add("West");
//        }
//        if (this.WithinBoundaries(this.x, this.y + 1)) {
//            if (this.East().type == "WhiteWalker")
//                positions.add("East");
//        }
//
//        return positions;
//    }
//    public boolean whiteWalkersNeighbours() {
//        if (this.WithinBoundaries(this.x - 1, this.y)) {
//            if (this.North().type == "WhiteWalker")
//                return true;
//        }
//        if (this.WithinBoundaries(this.x + 1, this.y)) {
//            if (this.South().type == "WhiteWalker")
//                return true;
//        }
//        if (this.WithinBoundaries(this.x, this.y - 1)) {
//            if (this.West().type == "WhiteWalker")
//                return true;
//        }
//        if (this.WithinBoundaries(this.x, this.y + 1)) {
//            if (this.East().type == "WhiteWalker")
//                return true;
//        }
//        return false;
//
//    }
//
//    public boolean WithinBoundaries(int x, int y) {
//        if (x <= grid.length && y <= grid[0].length && x >= 0 && y >= 0) {
//            return true;
//        }
//        return false;
//    }
//
//    /**
//     * @return a representation for the state grid.
//     */
//    public String toString() {
//        String count = "";
//        for (int i = 0; i < this.grid.length; i++) {
//            for (int j = 0; j < this.grid[i].length; j++) {
//                count += this.grid[i][j].type+"\t";
//            }
//            count += "\n";
//        }
//        return count;
//    }
//}
//public class westerosProblem extends Problem {
//
//    /**
//     * Problem Definition: grid dimensions and description.
//     * n -> number of rows in the grid.
//     * m -> number of columns in the grid.
//     * grid -> 2D array with characters defined in the mapping below.
//     */
//    public int n;
//    public int m;
//    public Cell[][] grid;
//    String[] types = {
//        "Free",
//        "WhiteWalker",
//        "Obstacle"
//    };
//    /**
//     * Constructs a new R2D2 problem. It randomly initializes a grid
//     * with the input dimensions and defines the problem operators.
//     * @param N the number of grid rows.
//     * @param M the number of grid columns.
//     */
//    public westerosProblem(int N, int M) {
//
//        this.n = N;
//        this.m = M;
//
//        initializeGrid(N, M);
//        initializeOperators();
//    }
//
//    /**
//     * Initializes the problem with a random grid.
//     * @param n the number of grid rows.
//     * @param m the number of grid columns.
//     */
//    public void initializeGrid(int n, int m) {
//        this.grid = new Cell[n][m];
//        for (int i = 0; i < this.grid.length; i++) {
//            for (int j = 0; j < this.grid[i].length; j++) {
//                this.grid[i][j] = new Cell(this.types[(int)(Math.random() * 3)]);
//            }
//        }
//        while (true) {
//            int x = (int)(Math.random() * 4);
//            int y = (int)(Math.random() * 4);
//            if (x != 3 && y != 3) {
//                System.out.println();
//                this.grid[x][y].type = "DragonStone";
//                break;
//            }
//        }
//        this.grid[3][3].type = "Jon";
//    }
//
//    /**
//     * Initializes the problem operators (moving in four directions).
//     */
//    public void initializeOperators() {
//        operators = new ArrayList < > ();
//        operators.add(new westerosOperators(-1, 0, "North", 1));
//        operators.add(new westerosOperators(0, -1, "West", 1));
//        operators.add(new westerosOperators(1, 0, "South", 1));
//        operators.add(new westerosOperators(0, -1, "East", 1));
//    }
//
//    /**.
//     * @return a representation for the problem grid
//     */
//    public String toString() {
//        StringBuilder ret = new StringBuilder();
//        for (int i = 0; i < n; ++i) {
//            ret.append(grid[i]).append("\n");
//        }
//        return ret.toString();
//    }
//
//    /**
//     * @return the operators of the R2D2 problem.
//     */
//    @Override
//    public ArrayList < Operator > getOperators() {
//        return operators;
//    }
//
//    /**
//     * @return the initial state of the R2D2 problem.
//     */
//    @Override
//    public State getInitialState() {
//
//        return new westerosState(n - 1, m - 1, grid,3 );
//    }
//
//    /**
//     * Tests whether the input state is a goal state. That's,
//     * the robot is at the teleport and it's already activated.
//     * @param state the state to test.
//     * @return true if the input state is a goal state.
//     */
//    @Override
//    public boolean testGoal(State state) {
//
//        westerosState testState = (westerosState)state;
//        if(testState.whiteWalkersCount==0){
//            return true;
//        }
//        return false;
//    }
//}
//
//	/**
//	 * R2D2Search function.
//	 *
//	 * Takes grid dimensions from the user and generates the problem
//	 * based on these dimensions. If the input dimensions are -1 -1, the user is
//	 * allowed to enter the grid manually.
//	 *
//	 * After grid initializations, the user is allowed to make multiple runs for
//	 * different search strategies. Available search strategies are:
//	 * 1. Breadth-First Search => BF
//	 * 2. Depth-First Search => DF
//	 * 3. Iterative-Deepening Search => ID
//	 * 4. Uniform-Cost Search => UC
//	 * 5. Greedy Search with 3 different heuristics => GRi, i = {1, 2, 3}
//	 * 6. A* Search with 3 different heuristics => ARi, i = {1, 2, 3}
//	 *
//	 * Available heuristics:
//	 * 1. The number of unmatched rocks multiplied by the push cost.
//	 * 2. The Manhattan distance from the robot to the furthest rock.
//	 * 3. The sum of Manhattan distances from each unmatched rock to
//	 * the nearest pad to it multiplied by the push cost.
//	 */
//	public static void main(String[] args) {
//		
//		Scanner sc = new Scanner(System.in);
//		// System.out.println("Enter grid dimensions separated by a single space");
//        // int n = sc.nextInt();
//        // int m = sc.nextInt();
//        int n = 4; 
//        int m = 4;
//		westerosProblem problem =  new westerosProblem(n, m);
//		System.out.println("Initial Grid\n------------");
//		System.out.println(problem.getInitialState());
//		while(true)
//		{
//			System.out.println("Enter search strategy (or \"done\")");
//			String strategy = sc.next();
//			if(strategy.equals("done"))
//				break;
//			QueueController controller = getController(strategy);
////			GeneralSearch.search(problem, controller, true);
//		}
//		sc.close();
//		
//	}
//
//	/**
//	 * Creates an instance of the search strategy / queuing function
//	 * used as defined by the user.
//	 * @param s the code of the queue controller to be instantiated.
//	 * @return the constructed queue controller.
//	 */
//	private static QueueController getController(String s)
//	{
//		if(s.equals("BF"))			//Breadth-First Search
//			return new BreadthFirstSearch();
//		if(s.equals("DF"))			//Depth-First Search
//			return new DepthFirstSearch();
////		if(s.equals("ID"))			//Iterative-Deepening Search
////			return new IterativeDeepeningSearch();
//		// if(s.equals("UC"))			//Uniform-Cost Search
//		// 	return new UniformCostSearch();
//
//		// Best-First Search
//		// EvaluationFunction evalFunc = getEvaluationFunction(s);
//		return null;
//	}
//
//	/**
//	 * Creates an evaluation function as defined by the input string.
//	 * @param s the code of the evaluation and heuristic functions.
//	 * @return the constructed evaluation function.
//	 */
//	// private static EvaluationFunction getEvaluationFunction(String s)
//	// {
//	// 	HeuristicFunction heurFunc = getHeuristicFunction(s);
//	// 	if(s.startsWith("GR"))
//	// 		return new GreedyEvaluationFunction(heurFunc);
//	// 	if(s.startsWith("AR"))
//	// 		return new AStarEvaluationFunction(heurFunc);
//	// 	return null;
//	// }
//
//	/**
//	 * Creates an evaluation function as defined by the input string.
//	 * @param s the code of the evaluation and heuristic functions.
//	 * @return the constructed heuristic function.
//	 */
//	// private static HeuristicFunction getHeuristicFunction(String s)
//	// {
//	// 	if(s.charAt(s.length() - 1) == '1')
//	// 		// return new RemainingRocksHeuristicFunction();
//	// 	if(s.charAt(s.length() - 1) == '2')
//	// 		// return new FurthestRockHeuristicFunction();
//	// 	if(s.charAt(s.length() - 1) == '3')
//	// 		// return new RockPadMatchingHeuristicFunction();
//	// 	return null;
//	// }
//}
