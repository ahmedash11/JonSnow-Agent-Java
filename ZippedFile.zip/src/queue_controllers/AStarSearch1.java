package queue_controllers;

import java.util.ArrayList;
import java.util.LinkedList;

import generic.Node;
import generic.State;
import saveWesteros.westerosState;

public class AStarSearch1 extends QueueController {

	private LinkedList<Node> queue = new LinkedList<>();;

	public AStarSearch1() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * Checks whether the queue is empty.
	 * 
	 * @return true if the queue is empty.
	 */
	@Override
	public boolean isEmpty() {
		return queue.isEmpty();
	}

	/**
	 * Adds the input expanded nodes to the queue (if they are not visited before).
	 * 
	 * @param nodes the nodes to be added to the queue.
	 */
	@Override
	public void add(ArrayList<Node> nodes) {
		for (Node node : nodes) {
//			Integer oldNodeCost = vis.get(node.getState());
//			Integer curNodeCost = nodeComparator.getNodeCost(node);
//			if (oldNodeCost == null || curNodeCost < oldNodeCost) {
//				vis.put(node.getState(), curNodeCost);
			if (visited.contains(node.state.elementsToString()) == false) {
				visited.add(node.state.elementsToString());
				if (queue != null) {
					int i = 0;
					for (Node element : queue) {
						if ((node.getPathCost() + heuristicFunction1(node)) < (element.getPathCost()
								+ heuristicFunction1(element)))
							break;
						i++;
					}
					queue.add(i, node);
					System.out.println(queue.toString());
				} else {
					queue.add(node);
				}
			}
		}
	}

	/**
	 * Removes the front of the queue which is the node chosen for relaxation. The
	 * front of the queue is based on a comparator function.
	 * 
	 * @return the removed node.
	 */
	@Override
	public Node removeFront() {
		return queue.remove();
	}

	public int heuristicFunction1(Node node) {
		int wwAlive = ((westerosState) node.state).whiteWalkersCount;
		int heuristic = (int) Math.ceil(wwAlive / 3);
		heuristic = heuristic * 5;

		return heuristic;

	}
}
