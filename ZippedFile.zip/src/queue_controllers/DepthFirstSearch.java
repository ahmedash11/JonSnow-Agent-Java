package queue_controllers;

import java.util.ArrayList;
import java.util.Stack;

import generic.Node;

/**
 * Depth-First Search
 */
public class DepthFirstSearch extends QueueController {

	private Stack<Node> stack = new Stack<>();

	/**
	 * Checks whether the queue is empty.
	 * 
	 * @return true if the queue is empty.
	 */
	@Override
	public boolean isEmpty() {
		return stack.isEmpty();
	}

	/**
	 * Adds the input expanded nodes to the queue (if they are not visited before).
	 * 
	 * @param nodes the nodes to be added to the queue.
	 */
	@Override
	public void add(ArrayList<Node> nodes) {
		for (Node node : nodes) {
			if(visited.contains(node.state.elementsToString()) == false) {
				visited.add(node.state.elementsToString());
				stack.push(node);
			}else {
				System.out.println(node.state.elementsToString());
			}

//			}
		}
	}

	/**
	 * Removes the front of the queue which is the node chosen for relaxation. The
	 * front of the queue in DepthFirstSearch is the last inserted node (LIFO).
	 * 
	 * @return the removed node.
	 */
	@Override
	public Node removeFront() {
		return stack.pop();
	}
}