package queue_controllers;

import java.util.ArrayList;
import java.util.LinkedList;

import generic.Node;

/**
 * Uniform-Cost Search
 */
public class UniformCostSearch extends QueueController {

	private LinkedList<Node> queue = new LinkedList<>();

	/**
	 * Constructs a uniform-cost queue controller based on the default comparator
	 * function.
	 */
	public UniformCostSearch() {
	}

	/**
	 * Checks whether the queue is empty.
	 * 
	 * @return true if the queue is empty.
	 */
	@Override
	public boolean isEmpty() {
//		while (!queue.isEmpty()) {
//			Node node = queue.peek();
//			queue.remove();
//		}
		return queue.isEmpty();
	}

	/**
	 * Adds the input expanded nodes to the queue (if they are not visited before).
	 * 
	 * @param nodes the nodes to be added to the queue.
	 */
	@Override
	public void add(ArrayList<Node> nodes) {
		for (Node node : nodes) {
//			Integer oldNodeCost = vis.get(node.getState());
//			Integer curNodeCost = nodeComparator.getNodeCost(node);
//			if (oldNodeCost == null || curNodeCost < oldNodeCost) {
//				vis.put(node.getState(), curNodeCost);
			if (visited.contains(node.state.elementsToString()) == false) {
				visited.add(node.state.elementsToString());
				if (queue != null) {
					int i = 0;
					for (Node element : queue) {
						if (node.getPathCost() < element.getPathCost())
							break;
						i++;
					}
					queue.add(i, node);
					System.out.println(queue.toString());
				} else {
					queue.add(node);
				}
			}

		}
	}

	/**
	 * Removes the front of the queue which is the node chosen for relaxation. The
	 * front of the queue is based on a comparator function.
	 * 
	 * @return the removed node.
	 */
	@Override
	public Node removeFront() {
		System.out.println("Here");
		System.out.println(queue.peek());
		System.out.println(queue.toString());
		return queue.remove();
	}
}
