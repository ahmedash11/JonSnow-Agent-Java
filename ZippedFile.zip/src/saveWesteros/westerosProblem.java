package saveWesteros;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Random;

import generic.Operator;
import generic.Problem;
import generic.State;

public class westerosProblem extends Problem {

    /**
     * Problem Definition: grid dimensions and description.
     * n -> number of rows in the grid.
     * m -> number of columns in the grid.
     * grid -> 2D array with characters defined in the mapping below.
     */
    public int n;
    public int m;
    public Cell[][] grid;
    String[] types = {
        "Free",
        "WhiteWalker",
        "Obstacle"
    };
    /**
     * Constructs a new R2D2 problem. It randomly initializes a grid
     * with the input dimensions and defines the problem operators.
     * @param N the number of grid rows.
     * @param M the number of grid columns.
     */
    public westerosProblem(int N, int M) {

        this.n = N;
        this.m = M;

        initializeGrid(N, M);
        initializeOperators();
    }

    /**
     * Initializes the problem with a random grid.
     * @param n the number of grid rows.
     * @param m the number of grid columns.
     */
    private void initializeGrid(int n, int m) {
        this.grid = new Cell[n][m];
        for (int i = 0; i < this.grid.length; i++) {
            for (int j = 0; j < this.grid[i].length; j++) {
                this.grid[i][j] = new Cell(this.types[(int)(Math.random() * 3)]);
            }
        }
        while (true) {
            int x = (int)(Math.random() * 4);
            int y = (int)(Math.random() * 4);
            if (x != 3 && y != 3) {
                this.grid[x][y].type = "DragonStone";
                break;
            }
        }
        this.grid[3][3].type = "Jon";
    }

    /**
     * Initializes the problem operators (moving in four directions).
     */
    private void initializeOperators() {
        operators = new ArrayList < > ();
        operators.add(new westerosOperators(-1, 0, "North", 1));
        operators.add(new westerosOperators(0, -1, "West", 1));
        operators.add(new westerosOperators(1, 0, "South", 1));
        operators.add(new westerosOperators(0, -1, "East", 1));
    }

    /**.
     * @return a representation for the problem grid
     */
    public String toString() {
        StringBuilder ret = new StringBuilder();
        for (int i = 0; i < n; ++i) {
            ret.append(grid[i]).append("\n");
        }
        return ret.toString();
    }

    /**
     * @return the operators of the R2D2 problem.
     */
    @Override
    public ArrayList < Operator > getOperators() {
        return operators;
    }

    /**
     * @return the initial state of the R2D2 problem.
     */
    @Override
    public State getInitialState() {

        return new westerosState(n - 1, m - 1, grid,3 );
    }

    /**
     * Tests whether the input state is a goal state. That's,
     * the robot is at the teleport and it's already activated.
     * @param state the state to test.
     * @return true if the input state is a goal state.
     */
    @Override
    public boolean testGoal(State state) {

        westerosState testState = (westerosState)state;
        if(testState.whiteWalkersCount==0){
            return true;
        }
        return false;
    }
    public String GridtoString() {
        String count = "";
        for (int i = 0; i < this.grid.length; i++) {
            for (int j = 0; j < this.grid[i].length; j++) {
                count += this.grid[i][j].type+"\t";
            }
            count += "\n";
        }
        return count;
    }

}