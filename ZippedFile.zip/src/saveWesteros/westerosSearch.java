package saveWesteros;

import java.util.*;
import generic.*;
import queue_controllers.*;
/**
import functions.AStarEvaluationFunction;
import functions.EvaluationFunction;
import functions.GreedyEvaluationFunction;
import functions.HeuristicFunction;
import r2d2.heuristics.FurthestRockHeuristicFunction;
import r2d2.heuristics.RemainingRocksHeuristicFunction;
import r2d2.heuristics.RockPadMatchingHeuristicFunction;
*/

/**
 * Run everything from here :)
 */
public class westerosSearch {

	/**
	 * R2D2Search function.
	 *
	 * Takes grid dimensions from the user and generates the problem
	 * based on these dimensions. If the input dimensions are -1 -1, the user is
	 * allowed to enter the grid manually.
	 *
	 * After grid initializations, the user is allowed to make multiple runs for
	 * different search strategies. Available search strategies are:
	 * 1. Breadth-First Search => BF
	 * 2. Depth-First Search => DF
	 * 3. Iterative-Deepening Search => ID
	 * 4. Uniform-Cost Search => UC
	 * 5. Greedy Search with 3 different heuristics => GRi, i = {1, 2, 3}
	 * 6. A* Search with 3 different heuristics => ARi, i = {1, 2, 3}
	 *
	 * Available heuristics:
	 * 1. The number of unmatched rocks multiplied by the push cost.
	 * 2. The Manhattan distance from the robot to the furthest rock.
	 * 3. The sum of Manhattan distances from each unmatched rock to
	 * the nearest pad to it multiplied by the push cost.
	 */
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		// System.out.println("Enter grid dimensions separated by a single space");
        // int n = sc.nextInt();
        // int m = sc.nextInt();
        int n = 4; 
        int m = 4;
		westerosProblem problem =  new westerosProblem(n, m);
		System.out.println("Initial Grid\n------------");
		System.out.println(problem.getInitialState());
		while(true)
		{
			System.out.println("Enter search strategy (or \"done\")");
			String strategy = sc.next();
			if(strategy.equals("done"))
				break;
			QueueController controller = getController(strategy);
			GeneralSearch.search(problem, controller, true);
		}
		sc.close();
		
	}

	/**
	 * Creates an instance of the search strategy / queuing function
	 * used as defined by the user.
	 * @param s the code of the queue controller to be instantiated.
	 * @return the constructed queue controller.
	 */
	private static QueueController getController(String s)
	{
		if(s.equals("BF"))			//Breadth-First Search
			return new BreadthFirstSearch();
		if(s.equals("DF"))			//Depth-First Search
			return new DepthFirstSearch();
		if(s.equals("ID"))			//Iterative-Deepening Search
			return new IterativeDeepeningSearch();
		 if(s.equals("UC"))			//Uniform-Cost Search
		 	return new UniformCostSearch();
		 if(s.equals("GS1"))			//Uniform-Cost Search
			 	return new GreedySearch1();
		 if(s.equals("AS1"))			//Uniform-Cost Search
			 	return new AStarSearch1();

		// Best-First Search
		// EvaluationFunction evalFunc = getEvaluationFunction(s);
		return null;
	}

}
