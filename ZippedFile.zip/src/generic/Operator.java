package generic;

/**
 * Abstract Operator class.
 */
public abstract class Operator {


	public String name;
	public int cost;


	public Operator(String name, int cost) {
		this.name = name;
		this.cost = cost;
	}

	/**
	 * Applies the operator to the input node.
	 * @param node the node to which the operator is applied.
	 * @return the new node after applying the operator.
	 */
	public abstract Node apply(Node node);

	// /**
	//  * @return the operator cost.
	//  */
	// public int getCost() {
	// 	return cost;
	// }

	// /**
	//  * @return the operator name.
	//  */
	// public String getName() {
	// 	return name;
	// }
}