package generic;

import java.util.ArrayList;

import saveWesteros.westerosProblem;

/**
 * Abstract Problem class
 */
public abstract class Problem {

	public ArrayList < Operator > operators;

	/**
	 * @return the operators of the problem.
	 */
	public abstract ArrayList < Operator > getOperators();

	/**
	 * @return the initial state of the problem.
	 */
	public abstract State getInitialState();

	/**
	 * Tests whether the input state is a goal state.
	 * @param state the state to be tested.
	 * @return true if the input state is a goal state.
	 */
	public abstract boolean testGoal(State state);

	public abstract String GridtoString();
}