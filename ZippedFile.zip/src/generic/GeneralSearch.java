package generic;

import java.util.ArrayList;

import queue_controllers.QueueController;
import saveWesteros.westerosProblem;
import saveWesteros.westerosState;

public class GeneralSearch {

	/**
	 * Expands the input node using the list of given operators.
	 * 
	 * @param node      the node to expand using the operators.
	 * @param operators the operators used to expand the node.
	 * @return the expanded nodes.
	 */
	private static ArrayList<Node> expand(Node node, ArrayList<Operator> operators) {
		ArrayList<Node> expandedNodes = new ArrayList<Node>();
		for (Operator operator : operators) {
			Node nxtNode = operator.apply(node);
			
			if (nxtNode != null) {
				System.out.print((((westerosState)nxtNode.state).x));
				System.out.println((((westerosState)nxtNode.state).y));
				System.out.println(nxtNode.state.toString());
				expandedNodes.add(nxtNode);
			}
		}
		return expandedNodes;
	}

	/**
	 * Searches for a solution to the input problem given a queue controller.
	 * 
	 * @param problem         the problem to be solved.
	 * @param queueController the queuing function used for node selection.
	 * @param visualize       a boolean to print the solution with some stats.
	 */
	public static void search(Problem problem, QueueController queueController, boolean visualize) {

		State initState = problem.getInitialState();

		queueController.makeQueue(new Node(initState, null, null));
		int expandedNodes = 0;
		while (!queueController.isEmpty()) {
			Node node = queueController.removeFront();
			expandedNodes++;
			if (problem.testGoal(node.getState())) {
				System.out.println("Goal Reached!");
				if (visualize) {
					printSolution(node);
					System.out.printf("Solution path length = %d\n", node.getDepth());
					System.out.printf("Solution path cost = %d\n", node.getPathCost());
					System.out.printf("# Expanded nodes = %d\n", expandedNodes);
					System.out.println(problem.GridtoString());
					System.out.println((((westerosState)node.state).WWPositionsKilled.toString()));
				}
				return;
			}
			ArrayList<Node> expanded = expand(node, problem.getOperators());
//			System.out.println(expanded.size());
			queueController.add(expanded);
//			System.out.println(queueController.isEmpty());
		}
		System.out.println("Failure :(");
	}

	/**
	 * Prints the states of the ancestors of the input node in addition to the state
	 * of the input node.
	 * 
	 * @param node the node to print its state and its ancestors states.
	 */
	private static void printSolution(Node node) {
		if (node.parent != null) {
			printSolution(node.parent);
			System.out.println(node.operator.name);
		}

//		System.out.println(node.state);
	}
}