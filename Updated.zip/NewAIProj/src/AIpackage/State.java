package AIpackage;

import java.util.ArrayList;
import java.util.List;


public class State {
	
	  List<Operators> actions = new ArrayList <Operators>();
	   Coordinates myPosition;
	   int WhiteWalkersLeft;
	   int DragonGlassCollected;
		ArrayList<Character> background = new ArrayList<Character>();
     	char Grid[][]= new char[4][4];


	public State(char Grid[][]) {
		for(int i=0; i<4; i++) {
			for(int j=0; j<4; j++) {
				this.Grid[i][j]= Grid[i][j];
			}
		}
		
	}
	
	// GETS THE NEIGHBOURS OF JON SNOW
	public void MyBackground() {
		int x = this.myPosition.x;
		int y = this.myPosition.y;
		if ((x + 1) < 4) {
			this.background.add(Grid[x + 1][y]);
		} // down
		if (x - 1 > -1) {
			this.background.add(Grid[x - 1][y]);
		} // up
		if ((y + 1) < 4)
			this.background.add(Grid[x][y + 1]); // right

		if ((y - 1) > -1)
			this.background.add(Grid[x][y - 1]); // left

//		for (int i = 0; i < state.background.size(); i++) {
//			System.out.println("My Background" + " " + state.background.get(i));
//		}

	}
	
	public void Operations() {
		int x = this.myPosition.x;
		int y = this.myPosition.y;
//		System.out.println(x + " " + y);

		if ((x - 1 > -1) && (this.Grid[x - 1][y] == '\0')) {
			this.actions.add(Operators.UP);
		}
		if ((x + 1 < 4) && (this.Grid[x + 1][y] == '\0')) {
			this.actions.add(Operators.DOWN);
		}
		if ((y - 1 > -1) && (this.Grid[x][y - 1] == '\0')) {
			this.actions.add(Operators.LEFT);
		}
		if ((y + 1 < 4) && (this.Grid[x][y + 1] == '\0')) {
			this.actions.add(Operators.RIGHT);
		}
		if (((x - 1 > -1) && (this.Grid[x - 1][y] == 'D')) || ((x + 1 < 4) && (this.Grid[x + 1][y] == 'D'))
				|| ((y - 1 > -1) && (this.Grid[x][y - 1] == 'D')) || ((y + 1 < 4) && (this.Grid[x][y + 1] == 'D'))) {
			this.actions.add(Operators.COLLECT);
		}
		if (((((x - 1 > -1) && (this.Grid[x - 1][y] == 'W')) || ((x + 1 < 4) && (this.Grid[x + 1][y] == 'W'))
				|| ((y - 1 > -1) && (this.Grid[x][y - 1] == 'W')) || ((y + 1 < 4) && (this.Grid[x][y + 1] == 'W'))))
				&& (this.DragonGlassCollected > 0)) {
			this.actions.add(Operators.KILL);

		}
	}

    



}
