package AIpackage;

import java.awt.GridBagConstraints;

public class Node {
State state;
Node parent;
Operators OperatorApplied; //to generate this node
int depth= 0;
int pathCost; //pathCost from root till this node
int heuristic=0;


public int getHeuristic() {
	return heuristic;
}


public Node(State state,Node parent, int cost) {
	this.state= state;
	this.parent= parent;
	if(parent==null) {
		this.depth=0;
		this.pathCost= 0;
	}
	else {
		this.depth= parent.depth+1;
		this.pathCost = parent.pathCost+cost;}
	//System.out.println("I just created a Node");
}




public int getDepth() {
	return depth;
}


public int getPathCost() {
	return pathCost;
}
public String toString() {
	return state.myPosition.x + " " + state.myPosition.y + " " 
+ state.DragonGlassCollected + " " + state.WhiteWalkersLeft + stringGrid(state.Grid) ;
	
}

public String stringGrid(char[][] G) {
	String grid = "";
	for (int x = 0; x < G.length; x++) {
		for (int y = 0; y < G[x].length; y++) {
			grid +="[" + G[x][y] + "]" + "" ;
		}
		
	}
	return grid;
}


}

