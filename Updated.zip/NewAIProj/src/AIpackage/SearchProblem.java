package AIpackage;

import java.util.ArrayList;
import java.util.Comparator;


public abstract class SearchProblem {
	
	ArrayList<State> stateSpace= new ArrayList<State>();
	State initialState;
	ArrayList <String> pathParsed= new ArrayList<String>();
	Boolean noans=false;

	abstract boolean GoalTest(Node n);
    abstract void pathCost(Node node, Operators o); //assigns cost to each path	
    public abstract State getNextState(Node n, Operators O);

    public Node GeneralSearch(SearchProblem s, String strategy) {
    	if(strategy=="IterativeDeepening") {
    		Node IDNode= IterativeDeepening(s);
    		return IDNode;
    	} 
    	Node root = new Node(s.initialState,null,0);
    	ArrayList <Node> q= new ArrayList< Node>();
    	q.add(root);
    	while(!(q.isEmpty())) {
    		Node currentNode= q.get(0);
    		pathParsed.add(currentNode.toString());
//    		System.out.println(currentNode.toString());
    		q.remove(0);
//    		currentNode.state.MyBackground();
    		currentNode.state.Operations();
    		
    		if (GoalTest(currentNode)) {
    			return currentNode;
    		}
//    		System.out.println("SIZE"+ currentNode.state.actions.size());
    		for(int i=0; i<currentNode.state.actions.size();i++) {
    			Operators o= currentNode.state.actions.get(i);
    			State nextState= getNextState(currentNode, o);
    			

    			Node n = new Node(nextState,currentNode,0);
    			if(pathParsed.contains(n.toString()))
    				break;

    			switch(strategy) {
    			case "BFS": q.add(n);
    			break;
    			case "DFS": q.add(n);
        		q.sort(Comparator.comparingInt(Node::getDepth).reversed());
        		break;
 
    			case "UC": 
    				pathCost(n, currentNode.state.actions.get(i));
    				q.add(n);
    				q.sort(Comparator.comparingInt(Node:: getPathCost));
    			break;
    			
    			case "GR":
    				h1(n);
    				q.add(n);
    				q.sort(Comparator.comparingInt(Node:: getHeuristic));
    				break;
    			case "A*":
    				pathCost(n, currentNode.state.actions.get(i));
    				h1(n);
    				n.heuristic=n.heuristic+n.pathCost;
    				q.add(n);
    				q.sort(Comparator.comparingInt(Node:: getHeuristic));
    				break;
    				
    			}
    		}
    	}
    		noans=true;
		return null;
    	
    }

	public Node IterativeDeepening(SearchProblem s) {
    	int maxdepth=4;
    	int currentdepth;
    	ArrayList<Node> q= new ArrayList<Node>();
    	for(int i=0;i<maxdepth;i++) {
    		Node root=new Node(s.initialState,null,0);
    		q.add(root);
    		currentdepth=i;
    		while(!(q.isEmpty())) {
			Node currentnode=q.get(0);
			pathParsed.add(currentnode.toString());
			q.remove(0);
			if(GoalTest(currentnode))
				return currentnode;
			if(currentnode.depth<currentdepth) {
				if(!(currentnode.state.actions.size()==0)) {
    		for(int j=0;j<currentnode.state.actions.size();j++) {
    			State state= getNextState(currentnode,currentnode.state.actions.get(j));
    			Node n= new Node(state,currentnode,0);
    			q.add(n);
        		q.sort(Comparator.comparingInt(Node::getDepth).reversed());

    			
    		}
			}
    		
    				}
    					}
    		
    	}
    	return null;
    }
	
	public void h1(Node n) {
		Coordinates var= new Coordinates(0, 0);
		int far = 0;
		for(int i=0;i<n.state.Grid.length;i++) {
			for(int j=0;j<n.state.Grid[i].length;j++) {
				if(n.state.Grid[i][j]=='W') {
					var.x=Math.abs(i-n.state.myPosition.x);
					var.y=Math.abs(j-n.state.myPosition.y);
					if(far<(var.x+var.y)) {
						far=var.x+var.y;
					}
				
				}
			}
			
		}	
		 n.heuristic=far;
	}
		}
