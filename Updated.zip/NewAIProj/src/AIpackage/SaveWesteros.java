package AIpackage;

import java.util.ArrayList;
import java.util.List;

import javax.swing.RootPaneContainer;

public class SaveWesteros extends SearchProblem {
	char Grid[][];
	int WhiteWalkers;
	int Obstacles;
	int DragonGlassCollected;
	int WhiteWalkersLeft;
	int DragonGlass;
	Coordinates GridCell;
	int GridSize;
	Operators move;
	Coordinates[] WhiteWalkersPos;
	Coordinates[] ObstaclesPos;
	Coordinates DragonGlassPos;
	Coordinates JonSnowPos;
	String background;
	int counter;

	public SaveWesteros(char Gridin[][]) {
		super();
		this.Grid = Gridin;
	}

	public char[][] GenerateGrid() {
		DragonGlass = (int) (Math.random() * (5 - 2) + 1) + 1;

		Grid[3][3] = 'J';
		JonSnowPos = new Coordinates(3, 3);

		WhiteWalkers = (int) (Math.random() * (6 - 1) + 1) + 1;
		WhiteWalkersLeft = WhiteWalkers;
		WhiteWalkersPos = new Coordinates[WhiteWalkers];

		Obstacles = (int) (Math.random() * (3 - 1) + 1) + 1;
		ObstaclesPos = new Coordinates[Obstacles];

//		System.out.println("WhiteWalkers  " + WhiteWalkers);

		for (int i = 0; i < WhiteWalkers; i++) {

			GridCell = new Coordinates((int) ((Math.random() * 4)), (int) ((Math.random() * 4)));

			if (Grid[GridCell.x][GridCell.y] == '\0') {
				Grid[GridCell.x][GridCell.y] = 'W';
				WhiteWalkersPos[i] = new Coordinates(GridCell.x, GridCell.y);

//				System.out.println(WhiteWalkersPos[i].x + "," + WhiteWalkersPos[i].y);

			} else {
				i = i - 1;
			}

		}
//		System.out.println("Obstacles  " + Obstacles);

		for (int i = 0; i < Obstacles; i++) {
			GridCell.x = (int) (Math.floor(Math.random() * 4));
			GridCell.y = (int) (Math.floor(Math.random() * 4));
			if (Grid[GridCell.x][GridCell.y] == '\0') {
				Grid[GridCell.x][GridCell.y] = 'O';
				ObstaclesPos[i] = new Coordinates(GridCell.x, GridCell.y);
//				System.out.println(ObstaclesPos[i].x + "," + ObstaclesPos[i].y);

			} else {
				i = i - 1;
			}

		}

		while (Grid[GridCell.x][GridCell.y] != '\0') {
			GridCell.x = (int) (Math.floor(Math.random() * 4));
			GridCell.y = (int) (Math.floor(Math.random() * 4));
			if (Grid[GridCell.x][GridCell.y] == '\0')
				break;
		}
		Grid[GridCell.x][GridCell.y] = 'D';
		DragonGlassPos = new Coordinates(GridCell.x, GridCell.y);
//		System.out.println(DragonGlassPos.x + "," + DragonGlassPos.y + " D");

		for (int x = 0; x < Grid.length; x++) {
			for (int y = 0; y < Grid[x].length; y++) {
				System.out.print("[" + Grid[x][y] + "]" + " \t");
			}
			System.out.println();
		}
		State initstate = new State(this.Grid);// new
		initstate.myPosition = new Coordinates(3, 3);// new
		this.initialState = new State(Grid);// new
		this.initialState = initstate;// new
		initstate.WhiteWalkersLeft = this.WhiteWalkers;// new
		initstate.DragonGlassCollected = this.DragonGlass;// new
		Node root = new Node(initstate, null, 0);
		System.out.println("--------------------------");
		MyBackground(root.state);
		Operations(root.state);
		return Grid;
	}

	// GETS THE NEIGHBOURS OF JON SNOW
	public void MyBackground(State state) {
		int x = state.myPosition.x;
		int y = state.myPosition.y;
		if ((x + 1) < 4) {
			state.background.add(Grid[x + 1][y]);
		} // down
		if (x - 1 > -1) {
			state.background.add(Grid[x - 1][y]);
		} // up
		if ((y + 1) < 4)
			state.background.add(Grid[x][y + 1]); // right

		if ((y - 1) > -1)
			state.background.add(Grid[x][y - 1]); // left

//		for (int i = 0; i < state.background.size(); i++) {
//			System.out.println("My Background" + " " + state.background.get(i));
//		}

	}

	public void printGrid(char[][] G) {
		for (int x = 0; x < G.length; x++) {
			for (int y = 0; y < G[x].length; y++) {
				System.out.print("[" + G[x][y] + "]" + " \t");
			}
			System.out.println();
		}
	}

	// GETS ALL POSSIBLE ACTIONS THAT CAN BE DONE IN THIS STATE
	public void Operations(State state) {
		int x = state.myPosition.x;
		int y = state.myPosition.y;

		if ((x - 1 > -1) && (state.Grid[x - 1][y] == '\0')) {
			state.actions.add(Operators.UP);
		}
		if ((x + 1 < 4) && (state.Grid[x + 1][y] == '\0')) {
			state.actions.add(Operators.DOWN);
		}
		if ((y - 1 > -1) && (state.Grid[x][y - 1] == '\0')) {
			state.actions.add(Operators.LEFT);
		}
		if ((y + 1 < 4) && (state.Grid[x][y + 1] == '\0')) {
			state.actions.add(Operators.RIGHT);
		}
		if (((x - 1 > -1) && (state.Grid[x - 1][y] == 'D')) || ((x + 1 < 4) && (state.Grid[x + 1][y] == 'D'))
				|| ((y - 1 > -1) && (state.Grid[x][y - 1] == 'D')) || ((y + 1 < 4) && (state.Grid[x][y + 1] == 'D'))) {
			state.actions.add(Operators.COLLECT);
		}
		if (((((x - 1 > -1) && (state.Grid[x - 1][y] == 'W')) || ((x + 1 < 4) && (state.Grid[x + 1][y] == 'W'))
				|| ((y - 1 > -1) && (state.Grid[x][y - 1] == 'W')) || ((y + 1 < 4) && (state.Grid[x][y + 1] == 'W'))))
				&& (state.DragonGlassCollected > 0)) {
			state.actions.add(Operators.KILL);

		}
	}

	@Override
	boolean GoalTest(Node n) {
		// TODO Auto-generated method stub
//		System.out.println(n.state);
//		System.out.println("WWWW" + n.state.WhiteWalkersLeft);
		if (n.state.WhiteWalkersLeft == 0) {
			return true;
		}
		return false;
	}

	public State getNextState(Node n, Operators O) {

		State nextState = new State(n.state.Grid);
//		System.out.println("REFEJE");
//		printGrid(n.state.Grid);
		nextState.WhiteWalkersLeft = n.state.WhiteWalkersLeft;
		nextState.DragonGlassCollected = n.state.DragonGlassCollected;
		nextState.myPosition = new Coordinates(n.state.myPosition.x, n.state.myPosition.y);

		switch (O) {
		case UP:
			nextState.Grid[n.state.myPosition.x - 1][n.state.myPosition.y] = 'J';
			nextState.myPosition.x = n.state.myPosition.x - 1;
			nextState.myPosition.y = n.state.myPosition.y;
			nextState.Grid[n.state.myPosition.x][n.state.myPosition.y] = '\0';
			break;
		case DOWN:
			nextState.Grid[n.state.myPosition.x + 1][n.state.myPosition.y] = 'J';
			nextState.myPosition.x = n.state.myPosition.x + 1;
			nextState.myPosition.y = n.state.myPosition.y;
			nextState.Grid[n.state.myPosition.x][n.state.myPosition.y] = '\0';
			break;
		case LEFT:
			nextState.Grid[n.state.myPosition.x][n.state.myPosition.y - 1] = 'J';
			nextState.myPosition.x = n.state.myPosition.x;
			nextState.myPosition.y = n.state.myPosition.y - 1;
			nextState.Grid[n.state.myPosition.x][n.state.myPosition.y] = '\0';
			break;
		case RIGHT:
			nextState.Grid[n.state.myPosition.x][n.state.myPosition.y + 1] = 'J';
			nextState.myPosition.x = n.state.myPosition.x;
			nextState.myPosition.y = n.state.myPosition.y + 1;
			nextState.Grid[n.state.myPosition.x][n.state.myPosition.y] = '\0';
			break;
		case KILL:
			int counter = 0;
			for (int i = 0; i < n.state.background.size(); i++) {
				if (n.state.background.get(i) == 'W') {
					counter++;
				}
			}
			if (counter > 0) {
				nextState.WhiteWalkersLeft = nextState.WhiteWalkersLeft - counter;
				nextState.DragonGlassCollected -= 1;
			}

			int x = n.state.myPosition.x;
			int y = n.state.myPosition.y;
			if ((x + 1) < 4) {
				if (nextState.Grid[x + 1][y] == 'W')
					nextState.Grid[x + 1][y] = '\0';
			}
			if (x - 1 > -1) {
				if (nextState.Grid[x - 1][y] == 'W')
					nextState.Grid[x - 1][y] = '\0';
			}
			if ((y + 1) < 4) {
				if (nextState.Grid[x][y + 1] == 'W')
					nextState.Grid[x][y + 1] = '\0';
			}
			if ((y - 1) > -1) {
				if (nextState.Grid[x][y - 1] == 'W')
					nextState.Grid[x][y - 1] = '\0';
			}
			break;
		case COLLECT:
			nextState.DragonGlassCollected += DragonGlass;
			break;
		}

		return nextState;
	}

	public static void main(String[] args) {
		char[][] tst = new char[4][4];
		Search(tst, "BFS", true);
//		SaveWesteros sw= new SaveWesteros(tst);
//		sw.GenerateGrid();
//		sw.initialState= new State(sw.Grid);
//		sw.initialState.myPosition=new Coordinates(3, 3);
//		sw.MyBackground(sw.initialState);
//		sw.Operations(sw.initialState);
//		System.out.println("size: "+sw.initialState.actions.size());
//		for(int i=0; i<sw.initialState.actions.size();i++) {
//			System.out.println(sw.initialState.actions.get(i));
//		}
//		Node root = new Node(sw.initialState, null, 0);
//		State next=null;
//		if(!(root.state.actions.isEmpty())) {
//		 next = sw.getNextState(root, root.state.actions.get(0));
//		System.out.println("Next position " +next.myPosition.x+ ", " +next.myPosition.y);}
//		//sw.TransitionFunc();
	}

	public static void Search(char[][] grid, String strategy, Boolean visualize) {
		SaveWesteros sw = new SaveWesteros(grid);
		sw.GenerateGrid();
		sw.GeneralSearch(sw, strategy);

		if (visualize) {
			for (int i = 0; i < sw.pathParsed.size(); i++) {
//				sw.printGrid(sw.pathParsed.get(i).state.Grid);
			}
			int size = sw.pathParsed.size();
//			System.out.println("Path Cost= " + sw.pathParsed.get(size - 1).pathCost);
			System.out.println("Number of Nodes= " + size);
//			for(int i=0; i< sw.pathParsed.size(); i++) {
//				System.out.println("SEQUENCE: "+ sw.pathParsed.get(i).);	
//				}
		}

	}

	@Override
	void pathCost(Node node, Operators o) {
		if (o == Operators.KILL)
			node.pathCost = 1;
		else
			node.pathCost = 5;

	}
}
