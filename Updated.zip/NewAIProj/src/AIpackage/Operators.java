package AIpackage;

public enum Operators {
	KILL,COLLECT,UP,DOWN,LEFT,RIGHT;

}
