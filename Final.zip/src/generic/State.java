package generic;

public abstract class State{

	public abstract String toString();
	public abstract String elementsToString();
}
